﻿var require = {
	baseUrl: "",
	paths: {
		'jquery': './Scripts/jquery',
		'MindFusion.Common': './Scripts/MindFusion.Common',
		'MindFusion.Gauges': './Scripts/MindFusion.Gauges',
	},
};
