<html lang="en">
<head>
    <meta charset="utf-8" />
	<title>Real Time Stock Chart</title>
	<script type="text/javascript" src="common/jquery.min.js"></script>
    <script type="text/javascript" src="common/jquery-ui.min.js"></script> 
	<script type="text/javascript" src="Scripts/config.js"></script>
	<script data-main="RealTimeStockChart" src="Scripts/require.js"></script>
	
</head>
<body>
<div style="position: absolute; top: 10px">
    <canvas width="1000px" height="800px" id="stockChart"></canvas>
</div> 
</body>
</html>