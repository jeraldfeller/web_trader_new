<?php

$blockchain_root = "https://blockchain.info/";
$blockchain_receive_root = "https://api.blockchain.info/";
$mysite_root = "https://webtrader.nanopips.com";
$secret = "dfab7c358";
$my_xpub = "xpub6Bp7p874odPKBKhtBTTz8Ad43Jp2oGvBHqNmBPzGDUYHdjUBS5FyWm15JSEfRwUaYAAe2bcdMKmie2rCuhStfZJq5nMMHgYZoxtrCNcDJrC";
$my_api_key = "2147541a-fe21-469e-843b-46c472e41ba7";

//Database
$mysql_host = 'localhost';
$mysql_username = 'nanopips_admin';
$mysql_password = 'dfab7c358bb163';
$mysql_database = 'nanopips_stock';

?>
