<?php
require $_SERVER['DOCUMENT_ROOT'] . '/Model/Init.php';
require $_SERVER['DOCUMENT_ROOT'] . '/Model/Socket.php';
$socket = new Socket();


$action = $_GET['action'];

switch ($action){
    case 'post':
        $data = json_decode($_POST['param'], true);
        $socket->postCurrentPrice($data['coin'].'_table', $data['dollarPrice'], $data['btcPrice']);
        echo true;
        break;
}
