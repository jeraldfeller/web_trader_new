<?php
require $_SERVER['DOCUMENT_ROOT'] . '/Model/Init.php';
require $_SERVER['DOCUMENT_ROOT'] . '/Model/Users.php';
$users = new Users();


$action = $_GET['action'];

switch ($action){
    case 'login':
        $data = json_decode($_POST['param'], true);
        $return = $users->userLoginFunction($data);
        echo $return;
        break;
    case 'pending-trades':
        $data = json_decode($_POST['param'], true);
        $return = $users->getPendingTradesFunction($data);
        echo $return;
        break;
    case 'register-trade':
        $data = json_decode($_POST['param'], true);
        $return = $users->registerTradesFunction($data);
        echo $return;
        break;
    case 'update-trades':
        $data = json_decode($_POST['param'], true);
        $return = $users->userUpdateTradesFunction($data);
        echo $return;
        break;
}