<?php

/**
 * Created by PhpStorm.
 * User: Grabe Grabe
 * Date: 2/25/2018
 * Time: 12:40 PM
 */
class Socket
{
    public $debug = FALSE;
    protected $db_pdo;

    public function pdoQuoteValue($value)
    {
        $pdo = $this->getPdo();
        return $pdo->quote($value);
    }

    public function postCurrentPrice($table, $dollarPrice, $btcPrice){
        $pdo = $this->getPdo();
        $sql = 'INSERT INTO `'.$table.'` (`dollar_price`, `btc_price`) VALUES ('.$dollarPrice.','.$btcPrice.')';
        $stmt = $pdo->prepare($sql);
        $stmt->execute();
    }



    public function getPdo()
    {
        if (!$this->db_pdo)
        {
            if ($this->debug)
            {
                $this->db_pdo = new PDO(DB_DSN, DB_USER, DB_PWD, array(PDO::ATTR_ERRMODE => PDO::ERRMODE_WARNING));
            }
            else
            {
                $this->db_pdo = new PDO(DB_DSN, DB_USER, DB_PWD);
            }
        }
        return $this->db_pdo;
    }
}
