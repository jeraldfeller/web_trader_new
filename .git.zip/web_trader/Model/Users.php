<?php


class Users
{
    public $debug = FALSE;
    protected $db_pdo;

    public function userLoginFunction($data)
    {

        // check if credential match

        $pdo = $this->getPdo();
        $sql = 'SELECT * FROM `users` WHERE `email` = "' . $data['email'] . '" AND `password` = "' . $data['password'] . '"';
        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        if($result != false){
                $return = array('success' => true,
                    'id' => $result['id'],
                    'email' => $result['email'],
                    'password' => $result['password'],
                    'funds' => $result['funds'],
                );

                $_SESSION['isLoggedIn'] = true;
                $_SESSION['userData'] = $return;
                $_SESSION['id'] = $result['id'];

                $success = true;
                $response = array($return);


        }else{
            $success = false;
            $response = array(
                'message' => 'Incorrect email or password.'
            );
        }


        return
            json_encode(
                array(
                    'success' => $success,
                    'response' => $response
                )
            );
    }


    public function getPendingTradesFunction($data){
        $timeNow = time();
        $pdo = $this->getPdo();
        $sql = 'SELECT * FROM `trades` WHERE `user` = '.$data['userId'].' AND `closing_time` >= '.$timeNow.'';
        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        $result = array();
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $row['remaining'] = $row['closing_time'] - $timeNow;
            $result[] = $row;
        }

        return json_encode($result);
    }

    public function registerTradesFunction($data){
        $expires = $data['expires'];
        $entryTime = time();
        $closingTime = $entryTime + $expires;
        $type = $data['type'];
        $pdo = $this->getPdo();
        $sql = 'INSERT INTO `trades` (`entry_time`, `closing_time`, `expires`, `type`, `user`, `ticker`, `open`, `leverage`, `payout`, `status`, `pair`) VALUES ('.$entryTime.', '.$closingTime.', '.$expires.', "'.$type.'", '.$data['userId'].', "' . $data['ticker']. '", '.$data['amount'].', '.$data['leverage'] . ', '.$data['payout'].', "' . $data['status'] . '", "' . $data['pair'] . '")';
        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        $tradeId = $pdo->lastInsertId();

        return json_encode(array('tradeId' => $tradeId));
    }

    public function userUpdateTradesFunction($data){
        $dateTime = date('Y-m-d H:i:s');
        $pdo = $this->getPdo();

        // update funds
        if($data['status'] == 'win'){
            $sql = 'UPDATE `users` SET `funds` = (`funds` + '.$data['winAmount'].') WHERE `id` = '.$data['userId'].'';
        }else{
            $sql = 'UPDATE `users` SET `funds` = (`funds` - '.$data['leverage'].') WHERE `id` = '.$data['userId'].'';
        }
        $stmt = $pdo->prepare($sql);
        $stmt->execute();

        // register logs
        $user = $this->getUserDataById($data['userId']);

        $sql = 'UPDATE `trades` SET `exec_time` = "' . $dateTime. '", `close` = '.$data['close'].', `balance` = ' . $user['funds']. ', `status` = "' . $data['status'] . '" WHERE `id` = '.$data['tradeId'].'';
        $stmt = $pdo->prepare($sql);
        $stmt->execute();

        if(isset($_SESSION['userData'])){
            $_SESSION['userData']['funds'] = $user['funds'];
        }
        return
            json_encode(
                array(
                    'success' => true,
                    'response' => array(
                        'funds' => $user['funds']
                    )
                )
            );
    }


    public function  cronGetTrades(){
        $timeNow = time();
        $pdo = $this->getPdo();
        $sql = 'SELECT * FROM `trades` WHERE `status` = "live" AND `closing_time` < '.$timeNow.'';
        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        $result = array();
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $result[] = $row;
        }

        return json_encode($result);
    }

    function getUserDataById($id){
        $pdo = $this->getPdo();
        $sql = 'SELECT * FROM `users` WHERE `id` = "' . $id . '"';
        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        return $result;
    }




    public function pdoQuoteValue($value)
    {
        $pdo = $this->getPdo();
        return $pdo->quote($value);
    }

    public function getPdo()
    {
        if (!$this->db_pdo)
        {
            if ($this->debug)
            {
                $this->db_pdo = new PDO(DB_DSN, DB_USER, DB_PWD, array(PDO::ATTR_ERRMODE => PDO::ERRMODE_WARNING));
            }
            else
            {
                $this->db_pdo = new PDO(DB_DSN, DB_USER, DB_PWD);
            }
        }
        return $this->db_pdo;
    }
}