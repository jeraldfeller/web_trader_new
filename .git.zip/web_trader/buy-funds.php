<?php
include 'includes/regular/require.php';
require 'Model/Users.php';
?>
<!DOCTYPE html>
<html>
<head>
    <title>ZoloTrader</title>
    <script src="http://code.jquery.com/jquery-3.2.1.min.js"></script>
    <link href="assets/css/bootstrap.css" rel="stylesheet">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link href="//cdn.rawgit.com/noelboss/featherlight/1.7.9/release/featherlight.min.css" type="text/css" rel="stylesheet" />
    <script src="//cdn.rawgit.com/noelboss/featherlight/1.7.9/release/featherlight.min.js" type="text/javascript" charset="utf-8"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" type="text/css" media="all" />

    <style>
        #chartdiv {
            width		: 100%;
            height		: 500px;
            font-size	: 11px;
        }
        .center-block {
            margin-left:auto;
            margin-right:auto;
            display:block;
        }
        .spacer {
            margin-top: 12px; /* define margin as you see fit */
        }
        .text-bold{
            font-weight: bold;
        }
        .amcharts-guide tspan{
            display: block;
            width: 100%;
            height: 44px;
            padding: 5px 24px;
            font-size: 18px;
            line-height: 2;
            color: #fff;
            background-color: #222222;
            background-image: none;
            border: 1px solid #0f0f0f;
            border-radius: 4px;
            text-decoration: overline underline;
            -webkit-text-fill-color: green; /* Will override color (regardless of order) */
            -webkit-text-stroke-width: 20px;
            -webkit-text-stroke-color: black;
            font-weight: bold;
        }
        .amcharts-export-menu {
            display: none;
        }
    </style>
    <script>
        var zoomEvents = [];
        if (screen.width <= 768) {
            location.href = 'go_mobile.php';
        }
    </script>
</head>
<body>
<div class="container" style="padding-top:1%;">

    <strong>
        <font color='#13D384' size='5'>Zolo</font>
        <font size='5'>Trader</font>
    </strong> |  |
    <a href='log.php?v='>Trade History</a> |
    <a href='affiliate'>Affiliate</a> | <a href='logout.php'>Logout</a><br />

</div>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12 spacer">
            <label>Address:</label>
            <input type="text" class="form-control crypto-address">
        </div>
        <div class="col-md-12 spacer">
            <label>Amount:</label>
            <input type="number" class="form-control amount">
        </div>
        <div class="col-md-12 spacer">
            <button class="btn btn-primary" id="buyBtn">Buy</button>
        </div>
    </div>
</div>
</body>
</html>

