<html>
<head>
    <title>Zolotrader Login</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" >
    <script src="http://code.jquery.com/jquery-3.2.1.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <img src='http://tandemloop.com/loader.png'>

</head>
<body>
<center>
    <div class="container">
        <h2>
            <strong><font color='#13D384' size='5'>Zolo</font><font size='5'>Trader</font></strong><br/>
        </h2>
        <br />
        <div class='row'>
            <!-- LOGIN FORM -->
            <div class="col-md-2 col-md-offset-5">
                <!-- Main Form -->
                <div class="login-form-1">

                        <div class="main-login-form">
                            <div class="row">
                                <div class="col-lg-2 ">
                                    <label for="lg_username" class="sr-only">Username</label>
                                    <input type="text" class="input-lg" id="lg_username" name="lg_username" placeholder="Username" size='25'>
                                </div>
                                <br />
                            </div>
                            <div class='row' style='padding-top:1em;'>
                                <div class="col-lg-2 ">
                                    <label for="lg_password" class="sr-only">Password</label>
                                    <input type="password" class="input-lg" id="lg_password" name="lg_password" placeholder="Password" size='25'>
                                </div>
                            </div>
                            <br />
                            <button class="btn btn-success btn-lg submit-btn"  style='background: #13D384;'>Login <i class="fa fa-chevron-right"></i></button><br />
                            <font color='red' class="error-message"></font>
                        </div>

                </div>
                <!-- end:Main Form -->
            </div>
        </div>
</center>
<img align='right' src='assets/img/secure.png'></div>
<script>
    $(document).ready(function(){
        $('.submit-btn').on('click', function(){
            $email = $('#lg_username').val();
            $password = $('#lg_password').val();
            if($email != '' && $password != ''){
                $data = {
                    email: $email,
                    password: $password
                };
                $.ajax({
                    url: 'Controller/user.php?action=login',
                    type: 'post',
                    dataType: 'json',
                    success: function (data) {
                        if(data.success == true){
                            $('.error-message').html('');
                            location.href = 'go.php';

                        }else{

                            $('.error-message').text(data.response.message);

                        }
                    },
                    data: {param: JSON.stringify($data)}
                });
            }else{
                $('.error-message').text('Please input email and password');
            }
        });
    });
</script>
</body>
</html>