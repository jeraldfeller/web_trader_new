<?php
$currentBtcPrice = json_decode(file_get_contents('http://coincap.io/page/BTC'), true)['price_usd'];
?>
<html>
<head>
    <title>Socket</title>
    <script src="http://code.jquery.com/jquery-3.2.1.min.js"></script>
    <link href="../assets/css/bootstrap.css" rel="stylesheet">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" type="text/css" media="all" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/socket.io/2.0.3/socket.io.js"></script>
</head>
<body>
<div class="container-fluid">
  <div id='trade'> open console </div>
</div>

<script type="text/javascript" language="JavaScript">
    $(document).ready(function(){
      $currentBtcPrice = <?=$currentBtcPrice?>;
      $pairPrices = {
          BTCUSD: $currentBtcPrice,
          BTCCNY: 0,
          BTCEUR: 0,
          BTCJPY: 0,
          ETHBTC: 0,
          ETHUSD: 0,
          ETCBTC: 0,
          LTCUSD: 0,
          LTCCNY: 0,
          LTCEUR: 0,
          LTCJPY: 0,
          XRPBTC: 0
      };
      $.getJSON('http://coincap.io/exchange_rates').done(function(responseRates){
          $rates = responseRates.rates;
          var socket = io.connect('https://coincap.io');
          socket.on('trades', function (tradeMsg) {
            $coin = tradeMsg.coin;
            $price = tradeMsg.message.msg.price;
            if($coin == 'BTC'){
              document.getElementById('trade').innerHTML = JSON.stringify(tradeMsg)
              $currentBtcPrice = $price;
              postCurrentPrice({coin: $coin, dollarPrice: $btcPrice, btcPrice: $btcPrice});

              $pairPrices.BTCUSD = $price;
              $pairPrices.BTCCNY = $currentBtcPrice * $rates['CNY'];
              $pairPrices.BTCEUR = $currentBtcPrice * $rates['EUR'];
              $pairPrices.BTCJPY = $currentBtcPrice * $rates['JPY'];
              $pairData = [
                  {pair: 'BTCUSD', amount: $price},
                  {pair: 'BTCCNY', amount: $currentBtcPrice * $rates['CNY']},
                  {pair: 'BTCEUR', amount: $currentBtcPrice * $rates['EUR']},
                  {pair: 'BTCJPY', amount: $currentBtcPrice * $rates['JPY']}

              ];

              postLastPairPrice($pairData);
            }else if($coin == 'ETH' || $coin == 'ETC' || $coin == 'LTC' || $coin == 'XRP'){

              switch($coin){
                case 'ETH':
                  $pairPrices.ETHUSD = $price;
                  $pairPrices.ETHBTC = $price / $currentBtcPrice;
                  $pairData = [
                      {pair: 'ETHUSD', amount: $price},
                      {pair: 'ETHBTC', amount: $price / $currentBtcPrice}

                  ];
                  break;
                case 'ETC':
                  $pairPrices.ETCBTC = $price / $currentBtcPrice;
                  $pairData = [
                      {pair: 'ETCBTC', amount: $price / $currentBtcPrice}
                  ];
                  break;
                case 'LTC':
                  $pairPrices.LTCUSD = $price;
                  $pairPrices.LTCCNY = $price * $rates['CNY'];
                  $pairPrices.LTCEUR = $price * $rates['EUR'];
                  $pairPrices.LTCJPY = $price * $rates['JPY'];

                  $pairData = [
                      {pair: 'LTCUSD', amount: $price},
                      {pair: 'LTCCNY', amount: $price * $rates['CNY']},
                      {pair: 'LTCEUR', amount: $price * $rates['EUR']},
                      {pair: 'LTCJPY', amount: $price * $rates['JPY']}

                  ];
                  break;
                case 'XRP':
                  $pairPrices.XRPBTC = $price / $currentBtcPrice;
                  $pairData = [
                      {pair: 'XRPBTC', amount: $price / $currentBtcPrice}

                  ];
                  break;
              }


              document.getElementById('trade').innerHTML = JSON.stringify(tradeMsg)
              $btcPrice = $price / $currentBtcPrice;
              postCurrentPrice({coin: $coin, dollarPrice: $price, btcPrice: $btcPrice});
              postLastPairPrice($pairData);
            }
          })
      });

    });

    function postCurrentPrice($data){
      $.ajax({
          url: '../Controller/socket.php?action=post',
          type: 'post',
          dataType: 'json',
          success: function (data) {

          },
          data: {param: JSON.stringify($data)}
      });
    }

    function postLastPairPrice($data){
      $.ajax({
          url: '../Controller/crypto.php?action=update',
          type: 'post',
          dataType: 'json',
          success: function (data) {

          },
          data: {param: JSON.stringify($pairData)}
      });
    }
</script>


</body>
</html>
